package main

import (
	"go-crud/db"
	"go-crud/routes"
)

func main(){
	db.Init()

	e := routes.Init()
	e.Logger.Fatal(e.Start("0.0.0.0:9696"))
}
