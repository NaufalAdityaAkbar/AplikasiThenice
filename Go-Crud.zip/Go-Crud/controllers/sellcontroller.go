package controllers

import (
	"go-crud/models"
	"net/http"

	"strconv"
	"github.com/labstack/echo/v4"
)

type ErrorResponse struct {
	Message string `json:"message"`
}

func PenjualanBarang(c echo.Context) error {
	result, err := models.Sell()
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}

	return c.JSON(http.StatusOK, result)
}

// Login owner
func LoginHandler(c echo.Context) error {
	
	var userLogin models.Login
	if err := c.Bind(&userLogin); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"message": "Invalid input"})
	}

	result, err := models.LoginUser(userLogin.Username, userLogin.Password)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}

	if result.Status != http.StatusOK {
		return c.JSON(http.StatusUnauthorized, map[string]string{"message": "Invalid username or password"})
	}

	return c.JSON(http.StatusOK, result)
}

//Login pegawai
func LoginPekerja(c echo.Context) error {
	
	var userLogin models.Pegawai
	if err := c.Bind(&userLogin); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"message": "Invalid input"})
	}

	result, err := models.LoginPegawai(userLogin.Username, userLogin.Password)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}

	if result.Status != http.StatusOK {
		return c.JSON(http.StatusUnauthorized, map[string]string{"message": "Invalid username or password"})
	}

	return c.JSON(http.StatusOK, result)
}



// Ulasan
func UlasanBalik(c echo.Context) error {
	var feedback models.Feedback
	if err := c.Bind(&feedback); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"message": "Invalid input"})
	}

	result, err := models.UlasanInsert(feedback.Name, feedback.Email, feedback.Subject, feedback.Message)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}

	return c.JSON(http.StatusOK, result)
}
func UlasanPengguna(c echo.Context) error {
	result, err := models.Ulasan()
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}

	return c.JSON(http.StatusOK, result)
}

// Gudang
func StokCreate(c echo.Context) error {
	var gudang models.Stok
	if err := c.Bind(&gudang); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"message": "Invalid input"})
	}
	// Pastikan stok_tiket yang diterima adalah int64
	result, err := models.StokPost(gudang.Wahana, gudang.Stok_tiket, gudang.Harga)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}

	return c.JSON(http.StatusOK, result)
}
func StokREQ(c echo.Context) error {
	result, err := models.StokGET()
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}

	return c.JSON(http.StatusOK, result)
}
func StokUPDATE(c echo.Context) error {
	var stok models.Stok
	if err := c.Bind(&stok); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"message": "Invalid input"})
	}

	result, err := models.StokUPDATE(stok.Id_Stok, stok.Wahana, stok.Stok_tiket, stok.Harga)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}
	return c.JSON(http.StatusOK, result)
}

func StokDELETE(c echo.Context) error {
	idParam := c.Param("id_stok")
	idStok, err := strconv.ParseInt(idParam, 10, 64)
	if err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"message": "Invalid input"})
	}
	result, err := models.StokDELETE(idStok)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}

	return c.JSON(http.StatusOK, result)
}

// Crud Laravel dan vb


func GetPembelian(c echo.Context) error {
	result, err := models.GetPembelian()
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}

	return c.JSON(http.StatusOK, result)
}

func GetPembelianKd(c echo.Context) error {
	var pembelian models.Pembelian
	if err := c.Bind(&pembelian); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"message": "Invalid input"})
	}

	result, err := models.GetPembelianKd(pembelian.Kd_pengguna)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}
	return c.JSON(http.StatusOK, result)
}

// Update Vb
func UpdatePembelian(c echo.Context) error {
	var pembelian models.Pembelian
	if err := c.Bind(&pembelian); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"message": "Invalid input"})
	}

	// Menghapus deklarasi variabel id yang tidak digunakan
	// id := pembelian.ID

	result, err := models.UpdatePembelian(pembelian)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}

	return c.JSON(http.StatusOK, result)
}

//Update Laravel

func DeletePembelian(c echo.Context) error {
	var pembelian models.Pembelian
	result, err := models.DeletePembelian(pembelian.Id)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}

	return c.JSON(http.StatusOK, result)
}

// chatowner get dan post
func ChatOwnerMessagesHandler(c echo.Context) error {
    arrobj, err := models.ChatOwnerMessages()
    if err != nil {
        return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
    }
    return c.JSON(http.StatusOK, arrobj)
}


func ChatOwnerPost(c echo.Context) error {
	var feedback models.Chatowner
	if err := c.Bind(&feedback); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"message": "Invalid input"})
	}

	result, err := models.ChatSendOwner(feedback.Id, feedback.Name, feedback.Pesan)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}

	return c.JSON(http.StatusOK, result)
}

// chatpetugas get dan post
func ChattingHandler(c echo.Context) error {
    arrobj, err := models.Chatting()
    if err != nil {
        return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
    }
    return c.JSON(http.StatusOK, arrobj)
}

func ChatPost(c echo.Context) error {
	var feedback models.Chat
	if err := c.Bind(&feedback); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"message": "Invalid input"})
	}

	result, err := models.ChatSend(feedback.Id, feedback.Name, feedback.Pesan)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
	}

	return c.JSON(http.StatusOK, result)
}


//viewpenjualan
func GetPenjualanViewHandler(c echo.Context) error {
    result, err := models.GetPenjualanView()
    if err != nil {
        return c.JSON(http.StatusInternalServerError, map[string]string{"message": err.Error()})
    }

    return c.JSON(http.StatusOK, result)
}