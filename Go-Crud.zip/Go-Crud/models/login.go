package models

import (
    
    "go-crud/db"
    "net/http"
)

type Login struct {
    Id       int64  `json:"id"`
    Username string `json:"username"`
    Password string `json:"password"`
}


func LoginUser(username, password string) (Response, error) {
    var obj Login
    var res Response

    con := db.CreateCon()

    sqlStatement := "SELECT id, username, password FROM login WHERE username=? AND password=?"

    // Debugging: Log the query and parameters
    // fmt.Println("Executing query:", sqlStatement, "with params:", username, password)

    rows, err := con.Query(sqlStatement, username, password)
    if err != nil {
        return res, err
    }
    defer rows.Close()

    if rows.Next() {
        err := rows.Scan(&obj.Id, &obj.Username, &obj.Password)
        if err != nil {
            res.Status = http.StatusInternalServerError
            res.Message = "Failed to scan row"
            return res, err
        }
    } else {
        res.Status = http.StatusUnauthorized
        res.Message = "Invalid username or password"
        return res, nil
    }

    res.Status = http.StatusOK
    res.Message = "Success"
    res.Data = obj

    return res, nil
}
