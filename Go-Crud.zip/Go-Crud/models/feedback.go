package models

import (
	"go-crud/db"
	"net/http"

)

type Feedback struct {
	Id      int64  `json:"id"`
	Name    string `json:"name"`
	Email   string `json:"email"`
	Subject string `json:"subject"`
	Message string `json:"message"`
}

func Ulasan() (Response, error) {
	var obj Feedback
	var arrobj []Feedback
	var res Response

	con := db.CreateCon()

	sqlStatement := "SELECT * FROM feedback"

	rows, err := con.Query(sqlStatement)

	defer rows.Close()

	if err != nil {
		return res, err
	}

	for rows.Next() {
		err = rows.Scan(&obj.Id, &obj.Name, &obj.Email, &obj.Subject, &obj.Message)
		if err != nil {
			return res, err
		}

		arrobj = append(arrobj, obj)
	}

	res.Status = http.StatusOK
	res.Message = "Berhasil"
	res.Data = arrobj

	return res, nil
}

func UlasanInsert(name string, email string, subject string, message string) (Response, error) {
	var res Response

	con := db.CreateCon()

	sqlStatement := "INSERT INTO feedback (name, email, subject, message)VALUES(?,?,?,?)"
	stmt, err := con.Prepare(sqlStatement)
	if err != nil {
		return res, err
	}

	result, err := stmt.Exec(name, email, subject, message)
	if err != nil{
		return res, err
	}
	getIdlast, err := result.LastInsertId()

	if err != nil{
		return res, err
	}

	res.Status = http.StatusOK
	res.Message = "sukses"
	res.Data = map[string]int64{
		"getIdLast" :getIdlast,
	}
	return res, nil
}
