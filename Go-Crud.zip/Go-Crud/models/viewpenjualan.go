package models

import (
    "go-crud/db"
    "net/http"
)

type PenjualanView struct {
    TanggalPembelian string  `json:"tanggal_pembelian"`
    JumlahTiket      int     `json:"jumlah_tiket"`
    TotalHarga       float64 `json:"total_harga"`
}

func GetPenjualanView() (Response, error) {
    var obj PenjualanView
    var arrobj []PenjualanView
    var res Response

    con := db.CreateCon()

    sqlStatement := "SELECT tanggal_pembelian, jumlah_tiket, total_harga FROM view_total_penjualan"

    rows, err := con.Query(sqlStatement)
    if err != nil {
        return res, err
    }
    defer rows.Close()

    for rows.Next() {
        err = rows.Scan(&obj.TanggalPembelian, &obj.JumlahTiket, &obj.TotalHarga)
        if err != nil {
            return res, err
        }
        arrobj = append(arrobj, obj)
    }

    res.Status = http.StatusOK
    res.Message = "Berhasil"
    res.Data = arrobj

    return res, nil
}
