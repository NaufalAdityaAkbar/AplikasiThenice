package models

import (
	"go-crud/db"
	"net/http"
)

type Chat struct {
	Id    int64  `json:"id"`
	Name  string `json:"name"`
	Pesan string `json:"pesan"`
}

func Chatting() (Response, error) {
	var obj Chat
	var arrobj []Chat
	var res Response

	con := db.CreateCon()

	sqlStatement := "SELECT * FROM chat"

	rows, err := con.Query(sqlStatement)

	defer rows.Close()

	if err != nil {
		return res, err
	}

	for rows.Next() {
		err = rows.Scan(&obj.Id, &obj.Name, &obj.Pesan)
		if err != nil {
			return res, err
		}

		arrobj = append(arrobj, obj)
	}

	res.Status = http.StatusOK
	res.Message = "Berhasil"
	res.Data = arrobj

	return res, nil
}

func ChatSend(id int64, name string, pesan string) (Response, error) {
	var res Response

	con := db.CreateCon()

	sqlStatement := "INSERT INTO chat (id, name, pesan) VALUES (?, ?, ?)"
	stmt, err := con.Prepare(sqlStatement)
	if err != nil {
		return res, err
	}

	result, err := stmt.Exec(id, name, pesan)
	if err != nil {
		return res, err
	}
	getIdLast, err := result.LastInsertId()

	if err != nil {
		return res, err
	}

	res.Status = http.StatusOK
	res.Message = "sukses"
	res.Data = map[string]int64{
		"getIdLast": getIdLast,
	}
	return res, nil
}
