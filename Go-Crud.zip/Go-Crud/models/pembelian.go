package models

import (
	"go-crud/db"
	"net/http"
)

type Pembelian struct {
    Id                int64   `json:"id_pembelian"`
    Kd_pengguna       string  `json:"kd_pengguna"`
    Email             string  `json:"email"`
    Wahana            string  `json:"wahana"`
    Tanggal           string  `json:"tanggal_pembelian"`
    Jumlah_tiket      int64   `json:"jumlah_tiket"`
    Total_harga       float64 `json:"total_harga"`
    Proses            string  `json:"proses"`
}
//Users Post
func PembelianTiket(kd_pengguna, email, wahana, tanggal_pembelian string, jumlah_tiket int64) (Response, error) {
	var res Response
	con := db.CreateCon()

	sqlStatement := "INSERT INTO pembelian (kd_pengguna, email, wahana, tanggal_pembelian, jumlah_tiket) VALUES (?, ?, ?, ?, ?)"
	stmt, err := con.Prepare(sqlStatement)
	if err != nil {
		return res, err
	}
	result, err := stmt.Exec(kd_pengguna, email, wahana, tanggal_pembelian, jumlah_tiket)
	if err != nil {
		return res, err
	}

	getIdLast, err := result.LastInsertId()
	if err != nil {
		return res, err
	}

	res.Status = http.StatusOK
	res.Message = "Berhasil menambahkan data baru"
	res.Data = map[string]interface{}{
		"lastInsertId": getIdLast,
	}

	return res, nil
}
//Get data by Kd_pengguna users
func GetPembelianKd(kd_pengguna string) ([]Pembelian, error) {
	var arrobj []Pembelian
	con := db.CreateCon()

	sqlStatement := "SELECT * FROM pembelian where kd_pengguna = ?"

	rows, err := con.Query(sqlStatement, kd_pengguna)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var obj Pembelian
		err := rows.Scan(&obj.Id, &obj.Kd_pengguna, &obj.Email, &obj.Wahana, &obj.Tanggal, &obj.Jumlah_tiket, &obj.Total_harga, &obj.Proses)
		if err != nil {
			return nil, err
		}
		arrobj = append(arrobj, obj)
	}

	return arrobj, nil
}

// Get all data
func GetPembelian() ([]Pembelian, error) {
	var arrobj []Pembelian
	con := db.CreateCon()

	sqlStatement := "SELECT * FROM pembelian"

	rows, err := con.Query(sqlStatement)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var obj Pembelian
		err := rows.Scan(&obj.Id, &obj.Kd_pengguna, &obj.Email, &obj.Wahana, &obj.Tanggal, &obj.Jumlah_tiket, &obj.Total_harga, &obj.Proses)
		if err != nil {
			return nil, err
		}
		arrobj = append(arrobj, obj)
	}

	return arrobj, nil
}

//User
// Update data pembelian
func UpdatePembelian(pembelian Pembelian) (Response, error) {
    var res Response

    con := db.CreateCon()

    sqlStatement := "UPDATE pembelian SET kd_pengguna = ?, email = ?, wahana = ?, tanggal_pembelian = ?, jumlah_tiket = ?, total_harga = ?, proses = ? WHERE id_pembelian = ?"
    stmt, err := con.Prepare(sqlStatement)
    if err != nil {
        return res, err
    }

    result, err := stmt.Exec(pembelian.Kd_pengguna, pembelian.Email, pembelian.Wahana, pembelian.Tanggal, pembelian.Jumlah_tiket, pembelian.Total_harga, pembelian.Proses, pembelian.Id)
    if err != nil {
        return res, err
    }

    rowsAffected, err := result.RowsAffected()
    if err != nil {
        return res, err
    }

    res.Status = http.StatusOK
    res.Message = "Sukses"
    res.Data = map[string]int64{
        "rowsAffected": rowsAffected,
    }

    return res, nil
}

//User dan pegawai
func DeletePembelian(id_pembelian int64) (Response, error) {
	var res Response
	con := db.CreateCon()

	sqlStatement := "DELETE FROM pembelian WHERE id_pembelian = ?"
	stmt, err := con.Prepare(sqlStatement)
	if err != nil {
		return res, err
	}
	_, err = stmt.Exec(id_pembelian)
	if err != nil {
		return res, err
	}

	res.Status = http.StatusOK
	res.Message = "Berhasil memperbarui data"

	return res, nil
}