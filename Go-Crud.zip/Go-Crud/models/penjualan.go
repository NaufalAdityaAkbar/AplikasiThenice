package models

import (
	"go-crud/db"
	"net/http"
	
)

type Penjualan struct {
	Id               int64  `json:"id"`
	Jumlah_penjualan int64  `json:"jumlah_penjualan"`
	Tanggal          string `json:"tanggal"`
}



func Sell() (Response, error) {
	var obj Penjualan
	var arrobj []Penjualan
	var res Response

	con := db.CreateCon()

	sqlStatement := "SELECT * FROM penjualan"

	rows, err := con.Query(sqlStatement)

	defer rows.Close();

	if err != nil{
		return res, err
	}

	for rows.Next(){
		err =rows.Scan(&obj.Id, &obj.Jumlah_penjualan, &obj.Tanggal)
		if err !=nil{
			return res, err
		}

		arrobj = append(arrobj, obj)
	}

	res.Status = http.StatusOK
	res.Message = "Berhasil"
	res.Data = arrobj

	return res, nil
}