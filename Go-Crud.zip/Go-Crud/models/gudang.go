package models

import (
	"go-crud/db"
	"net/http"

)

type Stok struct {
	Id_Stok      	 int64   `json:"id_stok"`
	Wahana   	 	string  `json:"wahana"`
	Stok_tiket   	int64  `json:"tiket"`
	Harga  		 	float64 `json:"harga"`
}

func StokGET() (Response, error) {
	var obj Stok
	var arrobj []Stok
	var res Response

	con := db.CreateCon()

	sqlStatement := "SELECT * FROM stok"

	rows, err := con.Query(sqlStatement)

	defer rows.Close()

	if err != nil {
		return res, err
	}

	for rows.Next() {
		err = rows.Scan(&obj.Id_Stok, &obj.Wahana, &obj.Stok_tiket, &obj.Harga)
		if err != nil {
			return res, err
		}

		arrobj = append(arrobj, obj)
	}

	res.Status = http.StatusOK
	res.Message = "Berhasil"
	res.Data = arrobj

	return res, nil
}

func StokPost(wahana string, tiket int64, harga float64) (Response, error) {
	var res Response

	con := db.CreateCon()

	sqlStatement := "INSERT INTO stok (wahana, tiket, harga)VALUES(?,?,?)"
	stmt, err := con.Prepare(sqlStatement)
	if err != nil {
		return res, err
	}

	result, err := stmt.Exec(wahana, tiket, harga)
	if err != nil{
		return res, err
	}
	getIdlast, err := result.LastInsertId()

	if err != nil{
		return res, err
	}

	res.Status = http.StatusOK
	res.Message = "sukses"
	res.Data = map[string]int64{
		"getIdLast" :getIdlast,
	}
	return res, nil
}

func StokDELETE(id_stok int64) (Response, error) {
	var res Response

	con := db.CreateCon()

	sqlStatement := "DELETE FROM stok WHERE id_stok = ?"
	stmt, err := con.Prepare(sqlStatement)
	if err != nil {
		return res, err
	}

	result, err := stmt.Exec(id_stok)
	if err != nil {
		return res, err
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return res, err
	}

	if rowsAffected == 0 {
		res.Status = http.StatusNotFound
		res.Message = "Record not found"
	} else {
		res.Status = http.StatusOK
		res.Message = "Sukses"
	}

	res.Data = map[string]int64{
		"rowsAffected": rowsAffected,
	}

	return res, nil
}

func StokUPDATE(id_stok int64, wahana string, tiket int64, harga float64) (Response, error) {
	var res Response

	con := db.CreateCon()

	sqlStatement := "UPDATE stok SET wahana = ?, tiket = ?, harga = ? WHERE id_stok = ?"
	stmt, err := con.Prepare(sqlStatement)
	if err != nil {
		return res, err
	}

	result, err := stmt.Exec(wahana, tiket, harga, id_stok)
	if err != nil {
		return res, err
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return res, err
	}

	res.Status = http.StatusOK
	res.Message = "Sukses"
	res.Data = map[string]int64{
		"rowsAffected": rowsAffected,
	}

	return res, nil
}