package routes

import (
    "go-crud/controllers"
    "net/http"

    "github.com/labstack/echo/v4"
)

func Init() *echo.Echo {
    e := echo.New()
    e.GET("/", func(c echo.Context) error {
        return c.String(http.StatusOK, "Hello, Selamat Datang")
    })

    // Laravel pembelian
    
    e.PUT("/pembelian/:id", controllers.UpdatePembelian)
    e.POST("/feedback", controllers.UlasanBalik)
    e.GET("/pembelian/:kd_pengguna", controllers.GetPembelianKd)
    e.DELETE("/pembelian/:id", controllers.DeletePembelian)

    // Flutter
    e.POST("/login", controllers.LoginHandler)
    e.GET("/feedback", controllers.UlasanPengguna)
    e.GET("/penjualan", controllers.PenjualanBarang)
    e.POST("/chatowner", controllers.ChatOwnerPost)
    e.GET("/chatowner", controllers.ChatOwnerMessagesHandler)
    e.GET("/chat", controllers.ChattingHandler)
	e.POST("/chat", controllers.ChatPost)
    e.GET("/view_total_penjualan", controllers.GetPenjualanViewHandler)  // New Route

    // Pegawai
    e.POST("/pegawai", controllers.LoginPekerja)
    e.GET("/pembelian", controllers.GetPembelian)
    e.PUT("/pembelian/:id", controllers.UpdatePembelian)

    // Visual Basic
    e.POST("/gudang", controllers.StokCreate)
    e.GET("/gudang", controllers.StokREQ)
    e.DELETE("/gudang/:id_stok", controllers.StokDELETE)
    e.PUT("/gudang/:id_stok", controllers.StokUPDATE)

    return e
}
